#importing the math module
import math
print('''
      welcome to CIRCLE CALC
      please enter your function in the space below the functions are:
          area with radius
          area with diameter
          perimeter with diameter
          perimeter with radius
          radius with perimeter
          radius with diameter
          diameter with perimeter 
          diameter with radius
        CIRCLE CALC is the property of CreativeDevil42.
        check out his github for more projects like this.
        dont forget to enter your values.
      ''')
func = (input("function "))
r = float(input("radius = "))
d = float(input("diameter = "))
c = float(input("perimeter = "))
pi = math.pi
tau = math.tau
if func == "area with radius":
    area = pi * r**2 
    print("area = ", area)
elif func == "area with diameter":
    area = pi * (d/2)**2
    print("area = ", area)
elif func == "perimeter with diameter":
    perimeter = pi * d
    print("perimeter = ", perimeter)
elif func == "perimeter with radius": 
    perimeter = tau * r
    print("perimeter = ", perimeter)
elif func == "radius with perimeter":
    radius = c / tau 
    print("radius = ", radius)
elif func == "radius with diameter":
    radius = d/2 
    print("radius = ", radius)
elif func == "diameter with perimeter":
    diameter = pi/c
    print("diameter = ", diameter)
elif func == "diameter with radius":
    diameter = 2*r
    print("radius = ", diameter)
elif func == "function":
    print("why")
    print("this does nothing.")
    print("why")
    print("just why")
    print("this isn't necessary")
    print("don't continue")
    print("i know what you're doing")
    print("no") 
    print("no") 
    print("no god please no")
    print("no") 
    print("no")
    print("noooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooo")
          
print("thank you for using CIRCLE CALC")
print("goodbye")    