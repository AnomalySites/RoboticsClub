#importing modules
from math import *
import math


x = (input("the first number in your calculation"))
operation = input("the operation you want to perform(use symbol, exept for roots, use yrt)")
y = float(input("the second value(not used in one unit equations)"))


if x == "pi":
    xpi = math.pi
if operation == "+":
    a = x + y
    print(a)
elif x == "pi":
    if operation == "+":
        addpi = xpi + y
        print(addpi)
if operation == "-":
    s = x - y
    print(s)
    if operation == "-":
        subpi = xpi - y
        print(subpi)
if operation == "*":
    m = x * y
    print(m)
if operation == "/":
    d = x / y
    print(d)
if operation == "^":
    if x == "pi":
        if operation == "^":
            p = xpi ** y   
    p = x ** y
    print(p) 
      
if operation == "yrt":
    yroot = x ** (1/y)
    print(yroot)
if operation == "!":
    fact = (math.factorial(x))
    print(fact)